import haynesAS1URLParser
import haynesAS1socket
import haynesAS1request
import time
import sys

def main():
    if len(sys.argv) != 2:
        print("Usage: python hw1.py URL")
        sys.exit(1)
    else:
        url = sys.argv[1]
    mysocket = haynesAS1socket.TCPsocket()  # create an object of TCP socket
    mysocket.createSocket()
    ps = haynesAS1URLParser.URLParser()
    host, port, path, query = ps.parse(url)
    print("URL:  " + url)
    print("Parsing URL... host " + str(host) + ", port " + str(port) + ", request")

    print("Doing DNS...")
    tic = time.perf_counter()
    ip = mysocket.getIP(host)
    toc = time.perf_counter()
    print(f"Done in {toc - tic:0.4f} ms, found " + ip)
    port = 80
    mysocket.connect(ip, port)

    # build our request
    myrequest = haynesAS1request.Request()
    print("Connecting on page...")
    msg = myrequest.headRequest(host)
    # send out request
    tic = time.perf_counter()
    mysocket.send(msg)
    toc = time.perf_counter()
    print(f"Done in {toc - tic:0.4f} ms")
    print("Loading...")
    tic = time.perf_counter()
    data = mysocket.receive()  # receive a reply from the server
    toc = time.perf_counter()
    print(f"done in {toc - tic:0.4f} ms with " + str(len(data)) + " bytes")
    print("Verifying header...")

    print("data received: ", data)

    mysocket.close()


# call main() method

if __name__ == "__main__":
    main()
