Emma Haynes

python hw1.py http://www.yahoo.com